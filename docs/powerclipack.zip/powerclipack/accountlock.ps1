﻿Write-Host "Loading VMware PowerCli..."
Connect-VIServer -Server 127.0.0.1
write-host "设置密码策略中..."
#$selectedlocation="马尾办公网虚拟化中心A"

$selectedlocation="VC_192.168.32.195"
get-vmhost -location $selectedlocation |  Get-AdvancedSetting -name Security.AccountLockFailures | Set-AdvancedSetting -Value 4 -Confirm:$false
get-vmhost -location $selectedlocation |  Get-AdvancedSetting -name Security.AccountUnlockTime | Set-AdvancedSetting -Value 600 -Confirm:$false

Write-Host "Disconnecting vCenter."
Disconnect-VIServer -Server 127.0.0.1 -Confirm:$false
Write-Host "Done."